#include "types.h"
#include "svc_nvm.h"

uint8 RAM_NWID[NWDATA_LEN];
const uint8 ROM_NWID[NWDATA_LEN] = {122, 122, 108, 49, SW_NAD};

