/* 
 * File:   config.h
 * Author: zlatko
 *
 * Created on January 7, 2019, 10:07 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

#define SW_NAD 80

//switch type
#define SWITCH_PUSH_BUTTON
//
//#define SWITCH_BISTABLE
//#define SWITCH_WINDOW


#endif	

