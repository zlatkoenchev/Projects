
#include "types.h"
#include "drv_io.h"
#include "svc_nvm.h"

#define ADC_RESOLUTION_01uV  20  //2mV resolution
#define TEMP_0_OFFSET   RAM_PARAM.C_TEMP_OFFS
#define TEMP_GAIN_01uV  RAM_PARAM.C_TEMP_GAIN



#define SW_DEB_MASK 0x07


void IO_TaskFast(void) {
   
    
}

void IO_TaskSlow(void){
   
}

void IO_TaskIdle(void){
   
}

void IO_Init(void){
    
    
}

void IO_StartTimer1(uint8 Time) {
}

void IO_StartTimer2(uint8 Time) {
   
}

void interrupt ISR(void) {
  
}

