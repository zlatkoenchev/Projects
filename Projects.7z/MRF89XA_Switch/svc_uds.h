/* 
 * File:   svc_uds.h
 * Author: zlatko
 *
 * Created on March 18, 2018, 6:23 PM
 */

#ifndef SVC_UDS_H
#define	SVC_UDS_H

void UDS_Init(void);
void UDS_WDBID(void);
void UDS_RDBID(void);
void UDS_GetSeed(void);
uint8 UDS_CompareKey(void);

#endif	

