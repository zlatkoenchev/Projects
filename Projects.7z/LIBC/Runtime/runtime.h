/* 
 * File:   runtime.h
 * Author: zlatko
 *
 * Created on July 21, 2018, 6:49 PM
 */

#ifndef RUNTIME_H
#define	RUNTIME_H

void Rnt_Init(void);
void Rnt_Task1Sec(void);
void Rut_Task1min(void);
void Rut_OnClearPower(void);
#endif	

