/* 
 * File:   app_RTC_cfg.h
 * Author: zlatko
 *
 * Created on June 8, 2018, 1:22 PM
 */

#ifndef APP_RTC_CFG_H
#define	APP_RTC_CFG_H


#define RESET_HOUR 23
#define RESET_MIN  59
#define RESET_SEC 40

#endif	

