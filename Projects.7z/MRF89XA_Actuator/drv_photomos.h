/* 
 * File:   drv_photomos.h
 * Author: zlatko
 *
 * Created on March 17, 2019, 1:33 PM
 */

#ifndef DRV_PHOTOMOS_H
#define	DRV_PHOTOMOS_H



void RelPM_Init(void) ;

void RelPM_Task(void); 

void RelPM_Request(uint8 breq);

#endif	

