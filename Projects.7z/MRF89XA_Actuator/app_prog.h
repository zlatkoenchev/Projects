/* 
 * File:   app_prog.h
 * Author: zlatko
 *
 * Created on June 9, 2018, 8:20 PM
 */

#ifndef APP_PROG_H
#define	APP_PROG_H

void PRG_Init(void);
void PRG_Task1s(void);
uint8 PRG_IsOnTime(void);

#endif	

