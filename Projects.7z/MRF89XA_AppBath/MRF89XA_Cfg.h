
#define PACKET_LEN 64
#define PAYLOAD_LEN 62


#define RSSI_ENABLED
#define ERROR_ENABLED



