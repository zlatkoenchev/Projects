/* 
 * File:   runtime_cfg.h
 * Author: zlatko
 *
 * Created on October 28, 2018, 10:54 AM
 */

#ifndef RUNTIME_CFG_H
#define	RUNTIME_CFG_H

uint16 Rtn_GetLoad1Power(void);
uint16 Rtn_GetLoad2Power(void);
#endif	

