/* 
 * File:   config.h
 * Author: zlatko
 *
 * Created on January 7, 2019, 10:07 PM
 */

#ifndef CONFIG_H
#define	CONFIG_H

//RTC
//#define USE_RTC_CHIP


//Temp sesnor
#define Si7021_PRESENT
//#define TMP36_PRESENT


//Actutor
#define ACTUATOR_PRESENT

//Energy
#define RUNTIME_PRESENT


#endif	

