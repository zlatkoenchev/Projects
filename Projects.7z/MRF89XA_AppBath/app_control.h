/* 
 * File:   app_control.h
 * Author: zlatko
 *
 * Created on July 23, 2018, 9:16 PM
 */

#ifndef APP_CONTROL_H
#define	APP_CONTROL_H

#define CTRL_OnACTFrame() 

#endif	

