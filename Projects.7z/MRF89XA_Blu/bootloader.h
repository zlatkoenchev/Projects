/* 
 * File:   bootloader.h
 * Author: zlatko
 *
 * Created on January 28, 2018, 12:04 PM
 */

#ifndef BOOTLOADER_H
#define	BOOTLOADER_H



void Boot_EraseFbl(void);
void Boot_ProgrFbl(void) ;

#endif	

