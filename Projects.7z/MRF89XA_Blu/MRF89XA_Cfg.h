#include "types.h"
#define PACKET_LEN 64
#define PAYLOAD_LEN 63

//#define TX_POLLING 
//#define RX_POLLING

#define RSSI_ENABLED

//#define ERROR_ENABLED