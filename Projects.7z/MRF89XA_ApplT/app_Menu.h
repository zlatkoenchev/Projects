/* 
 * File:   app_Menu.h
 * Author: zlatko
 *
 * Created on March 4, 2018, 7:12 PM
 */

#ifndef APP_MENU_H
#define	APP_MENU_H

void MNU_Init(void);
void MNU_Task(void);
void MNU_TaskButton(void);

#endif	

