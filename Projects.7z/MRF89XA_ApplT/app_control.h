/* 
 * File:   app_control.h
 * Author: zlatko
 *
 * Created on June 30, 2018, 6:14 PM
 */

#ifndef APP_CONTROL_H
#define	APP_CONTROL_H

void CTRL_OnACTFrame(void);
void App_OnAirSensFrame(void);
#endif	

