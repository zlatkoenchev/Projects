/* 
 * File:   msgs.h
 * Author: zlatko
 *
 * Created on March 9, 2018, 7:40 PM
 */

#ifndef MSGS_H
#define	MSGS_H
#endif	

