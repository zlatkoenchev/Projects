/*************************************************************************
 *
 *
 *    (c) Copyright Olimex 2010
 *
 *    File name   : extcon_test.C
 *    Description : External connectors test
 *
 *    History :
 *    1. Date        : 25, January 2010
 *       Author      : Aleksandar Mitev
 *       Description : Create
 *
 **************************************************************************/
#include <stdio.h>


