//#define TX_POLLING 
//#define RX_POLLING

#define PACKET_LEN 64
#define PAYLOAD_LEN 63

#define RSSI_ENABLED

