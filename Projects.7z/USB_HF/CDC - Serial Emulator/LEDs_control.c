/*************************************************************************
 *
 *
 *    (c) Copyright Olimex 2010
 *
 *    File name   : LEDs_control.c
 *    Description : Functions to control the LEDs onthe board
 *
 *    History :
 *    1. Date        : 25, January 2010
 *       Author      : Aleksandar Mitev
 *       Description : Create
 *
 **************************************************************************/

#include "GenericTypeDefs.h"
#include "Compiler.h"
#include "PinManipulation.h"
#include "LEDs_control.h"




