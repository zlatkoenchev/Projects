/********************************************************
 *		PIC-P2xj50 DEMO PROGRAM
 ********************************************************/

This is a siple demo project that demonstrates the features of the board.
After programming the board with the provided firmware you should connect it to a PC through the mini USB connector.
The board is powered up and you can see the LEDs flashing in a sequence. Pressing the button (the big one) you can toggle
between bar mode and single LED mode.
The program initializes the board to act as a virtual COM port. Connecting it for the first time to a PC you may be asked
to supply the necessary drivers, which are located in the '\inf' folder. After installing the driver you can test the
functionality of the COM port by starting a terminal program and shortenning pins 3 and 4 of the UEXT connector to get an
echo effect.

enjoy :)