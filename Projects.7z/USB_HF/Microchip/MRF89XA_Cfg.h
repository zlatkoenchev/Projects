
#define PACKET_LEN 64
#define PAYLOAD_LEN 62

//todo CSD/CSC/IRQ
#define IRQ1_pin  0  //todo

#define DATA_CS(x)  //todo 
#define REG_CS(x)

