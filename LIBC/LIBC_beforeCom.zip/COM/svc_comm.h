/* 
 * File:   bootloader.h
 * Author: zlatko
 *
 * Created on January 28, 2018, 12:04 PM
 */

#ifndef SVC_COMM_H
#define	SVC_COMM_H
#include "Protocol.h"
#include "MRF89XA.h"
#include "svc_comm_cfg.h"



extern uint8 MY_NAD;
#define Comm_GetMyNAD() MY_NAD

#define COM_RETRY_TX 3

void NEG_RESP(uint8 c);

void POS_RESP(uint8 len);

#define Comm_MsgHeader(Len,DNAD, CMD)  TxDEST_NAD = DNAD;TxDataLen = (Len+4);TxCMD = CMD

void Comm_Init(void);

void Comm_Task(void);

void Comm_OnIdle(void);

uint8 Comm_CanTransmit(void);

void Comm_Transmit(void);


#endif	

