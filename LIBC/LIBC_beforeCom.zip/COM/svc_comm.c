#include "types.h"
#include "svc_comm.h"
#include "drv_eep.h"
#include "MRF89XA.h"
#include "main.h"
#include "drv_io.h"
#include "app_RTC.h"
#include "app_Presence.h"
#include "svc_uds.h"
#include "svc_nvm.h"
#include "main.h"
#include "app_control.h"
#ifdef NM_ACIVE
#include "svc_nm.h"
#endif
#ifdef RUNTIME_PRESENT 
#include "runtime.h"
#endif

#define APP_VALID_FLAG_ADDR 0xFF
#define APPL_START_ADDR 0x500
#define APPL_END_ADDR 0x2000
#define FLASH_PAGE 32

#define NO_RESP()    TxCMD = CMD_NONE;TxDataLen=0;
#define APP_TX_ON        0x01
#define APP_RX_ON        0x02
#define APP_UNLOCK       0x04


#define MIN_RSSI        130 //-65dB
#define TX_RETRY        2
#define CSMA_RETRY      5

enum { 
    COM_IDLE_RX, //RX
    COM_TRANSMIT, //Wait for free air
    COM_WAIT_ACK, //wait for ACK
    COM_TX_ACK
}TStates;


uint8 MY_NAD;
static uint8 State;
static uint8 Retries;
static uint8 CSRetries;
static uint8 ComFlags;
static uint8 ComFailures;

static void TransmitFrame(void);

 void NEG_RESP(uint8 c){
     if (RxDEST_NAD() != 0) {
        TxCMD = CMD_NEG_RESP;
        TxData(0) = c;
        TxDataLen = 5; //l,da,sa,res,cmd, data
     }
}

 void POS_RESP(uint8 len){
     if (RxDEST_NAD() != 0) {
        TxCMD = RxCMD();
        TxDataLen = (uint8)len+4; //l,da,sa,res,cmd, data
     }
}

static void ACK_RESP(void){
    if (MY_NAD != 254)
    {
        POS_RESP(0);
    }
}

static void Comm_InitMRF(void) {
    if (FALSE == MRF89XAInit()) {
        asm("RESET");
    }
    //data valid?
    MRF89XARegisterSet(REG_SYNCBYTE0, RAM_NWID[0]);
    MRF89XARegisterSet(REG_SYNCBYTE1, RAM_NWID[1]);
    MRF89XARegisterSet(REG_SYNCBYTE2, RAM_NWID[2]);
    MRF89XARegisterSet(REG_SYNCBYTE3, RAM_NWID[3]);
    MY_NAD = RAM_NWID[4];
    MRF89XARegisterSet(REG_NODEADDRESS, MY_NAD);
    
}

void Comm_Init(void){
    
    Comm_InitMRF();
 
    //send ecu reset response
    TxCMD = CMD_ECURESET;
    TxDataLen = 5;
    TxDEST_NAD = 255;
    TransmitFrame();
    MRF89XAStartReception(); 
    
    ComFlags = APP_TX_ON | APP_RX_ON;//enable rx/tx
    State = COM_IDLE_RX;
    ComFailures = 0;
    //RAM_ERROR[3]++;
    //NVM_WriteBlock(NVM_ERROR);
}

static void TransmitFrame(void) {
    TxSRC_NAD = MY_NAD;
    TxRSV = 0;
    MRF89XASendFrame();
    IO_StartTimer1(IO_TimeMS(26)); //TX frame time should be below 16ms
    while ((MRF89XAIsBusy()) && (!IO_IsTimer1Elapsed())){
    
    }
    //problem a transmission?
    if (IO_IsTimer1Elapsed()) {
        Comm_InitMRF();
    } else {
        MRF89XASetRFMode(RF_STANDBY);
    }
}

static void Comm_RxProcess(void){
   
   NO_RESP(); //assume no response
    switch (RxCMD()) {
      case CMD_GLOB_TIME:
          RTC_OnRTCFrame();
          //no ack - broadcast
          break;
#ifdef REMOTE_AIR_SENS_PRESENT
      case CMD_SENS_AIR:
          App_OnAirSensFrame();
          //no ack - broadcast
          break;
#endif
#ifdef RUNTIME_PRESENT         
        case CMD_ENERGY_CLR:
            Rut_OnClearPower();
            break;
#endif
       case CMD_SENS_PIR:
          PRS_OnPIRFrame();
          //no ack - broadcast
          break;
          
      case CMD_GETSEED:
          if (RxDEST_NAD() != 0){
                UDS_GetSeed();
          }
         break;

       case CMD_SENDKEY:
           if (RxDEST_NAD() != 0) {
                if (UDS_CompareKey()) {
                       ComFlags |= APP_UNLOCK; 
                }
           }
         break;

        case CMD_INVALIDATE:
            if (RxDEST_NAD() != 0) {
                if (ComFlags & APP_UNLOCK) {
                    Write_Eep(APP_VALID_FLAG_ADDR, 255);
                    POS_RESP(0);
                }
            }
         break;
           
        case CMD_WRITE:
            NEG_RESP(0x22);
            if (RxDEST_NAD() != 0) {
                if (ComFlags & APP_UNLOCK) {
                    UDS_WDBID();
                }
            }
            break;
            
         case CMD_READ:
            NEG_RESP(0x22);
            if (RxDEST_NAD() != 0) {
                UDS_RDBID();
            }
            break;
                
          case CMD_ECURESET:
            if (RxDEST_NAD() != 0) {
                if (ComFlags & APP_UNLOCK) {
                    RequestReset();
                }
            }
          break;

          case CMD_COM_CTL:
             if (0xA4 == RxData(C_PAGE)) {
                ComFlags &= ~APP_TX_ON;  
             } else if (0x4A == RxData(C_PAGE)) {
                 ComFlags |= APP_TX_ON;  
             }
          break;
#ifdef ACTUATOR_PRESENT          
        case CMD_ACTUTAOR:
            if (RxDEST_NAD() != 0) {
                CTRL_OnACTFrame();
            }
            ACK_RESP();
           break;
#endif          
#ifdef NM_ACIVE
        case CMD_APPL_NM:
           NM_OnNmMessage();
          break;
#endif               
          default:
              
          break;
    }
   
   
   if (TxCMD != CMD_NONE)
   {     
        State = COM_TX_ACK;
        IO_StartTimer1(IO_Time1ms);
        TxDEST_NAD = RxSRC_NAD();
   }
}

void Comm_Transmit(void) {
   if (TxCMD != CMD_NONE){
        Retries = TX_RETRY;
        CSRetries = CSMA_RETRY;
        State = COM_TRANSMIT;
        IO_StartTimer1(IO_Time512us);//send asap
   }
}

uint8 Comm_CanTransmit(void) {  
    if ((COM_IDLE_RX == State) && (APP_TX_ON & ComFlags)){
        return TRUE; 
    }
    return FALSE;
}

void Comm_OnIdle(void){ 
    switch (State)
    {
        case COM_TRANSMIT:    
            if (!IO_IsTimer1Elapsed()) {return;}
            MRF89XACheckRSSI();
            if (MRF89XA_RSSI > MIN_RSSI)
            {
                //channel busy
                IO_StartTimer1(IO_TimeMS(20));//wait 20ms and try again
                if (CSRetries) {
                    CSRetries--;
                }
                else 
                {
                    if (ComFailures < 255) {
                        ComFailures++;
                    }
                    State = COM_IDLE_RX; //abort transmission
                    MRF89XAStartReception();
                }
            }
            else {
                TransmitFrame();
                MRF89XAStartReception();
                if (0 != TxDEST_NAD) { //unicast frame - wait for ACK
                    State = COM_WAIT_ACK;
                    IO_StartTimer1(IO_TimeMS(60));
                } else {
                    State = COM_IDLE_RX;
                }
            }
         break;
      case COM_IDLE_RX: 
          MRF89XATask();
          if (RxDataLen) {
              Comm_RxProcess();
              MRF89XAStartReception();
          } else if (MRF89XA_Error) {
                Comm_InitMRF();
                MRF89XAStartReception();
          }
          break;
          
      case COM_WAIT_ACK:
         MRF89XATask();
         if ((C_MSG_ID == RxDataLen) && 
             (TxDEST_NAD == RxSRC_NAD()) &&
             (RxCMD() == TxCMD)) 
         {
             //ack received!
             State = COM_IDLE_RX;
             MRF89XAStartReception();
         }  
         else if (IO_IsTimer1Elapsed())
         {
            if (Retries) {
                Retries--;
                CSRetries = CSMA_RETRY;
                State = COM_TRANSMIT;
            }
            else 
            {
                if (ComFailures < 255) {
                    ComFailures++;
                }
                State = COM_IDLE_RX; //abort transmission
                MRF89XAStartReception();
            }
         }
         if (MRF89XA_Error) {
                Comm_InitMRF();
                MRF89XAStartReception();
         }
        break;
        
     case COM_TX_ACK:    
       if (IO_IsTimer1Elapsed()) {
            TransmitFrame();
            MRF89XAStartReception();
            State = COM_IDLE_RX;
       }
       break;
    }
}




