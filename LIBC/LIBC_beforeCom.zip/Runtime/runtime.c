#include "types.h"
#include "svc_nvm.h"
#include "svc_comm.h"
#include "runtime_cfg.h"

uint8 bTxdata;

TRuntime RAM_RUNTIME;
const TRuntime ROM_RUNTIME = {0, 0};

void Rnt_Init(void) {
   bTxdata = 0;
}

void Rnt_Task1Sec(void){
    RAM_RUNTIME.LoadEnergy1 += Rtn_GetLoad1Power();//1w/s resolution
    RAM_RUNTIME.LoadEnergy2 += Rtn_GetLoad2Power(); //1w/s resolutio
  
    if (bTxdata & 1){
        if (Comm_CanTransmit()) {
            Comm_MsgHeader(8, 0, CMD_ENERGY_INFO);
            TxData(0) = (uint8) (RAM_RUNTIME.LoadEnergy1 >> 24);
            TxData(1) = (uint8) (RAM_RUNTIME.LoadEnergy1 >> 16);
            TxData(2) = (uint8) (RAM_RUNTIME.LoadEnergy1 >> 8);
            TxData(3) = (uint8) (RAM_RUNTIME.LoadEnergy1);
            TxData(4) = (uint8) (RAM_RUNTIME.LoadEnergy2 >> 24);
            TxData(5) = (uint8) (RAM_RUNTIME.LoadEnergy2 >> 16);
            TxData(6) = (uint8) (RAM_RUNTIME.LoadEnergy2 >> 8);
            TxData(7) = (uint8) (RAM_RUNTIME.LoadEnergy2);
            Comm_Transmit();
            bTxdata = 0;
        }
    }
}

void Rut_Task1min(void) {
    bTxdata = 1;   
}

void Rut_OnClearPower(void){
    RAM_RUNTIME.LoadEnergy1 = 0;
    RAM_RUNTIME.LoadEnergy2 = 0;
}
